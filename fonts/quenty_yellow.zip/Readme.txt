Hello,

Thank for purchasing and using my font!.
we hope you enjoy this font. If you have any questions please don't hesitate to drop me a message

Thank you,
Best regards
Twinletter


How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/



How to access alternate glyphs? you can see it on this link 

http://goo.gl/1vy2fv

